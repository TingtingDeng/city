import React from 'react';
import css from './ImageList.module.css'

const ImageList = ({images}) => {
    console.log('images got from ImageList', images)
    return (
        <div className={css.Carousel}>
            {
                images &&
                images.map((img, index) => {
                    return <div key={index} style={{background: `url('{img.thumb}') no-repeat center center fixed`}}></div>

            })
            }

        </div>
    );
};

export default ImageList;