
import React, {useState} from "react";
import InputCity from "./components/InputCity";
import ImageList from "./components/ImageList";





function App() {

    const [images, setImages] = useState([])
    const imagesFromInput = (data) => setImages(data)


    return (
       <div>

           <InputCity fun={imagesFromInput}/>
           <ImageList images = {images}/>




       </div>

    );
}


export default App;
