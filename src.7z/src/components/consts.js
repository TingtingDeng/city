export const DefaultCity = 'Ottawa';
export const BasicUrl = 'https://api.unsplash.com/search/photos';
export const AccessKey =  'KTpHGs6kBplI2wcZ8Axmw9lWOClODr8MaRe_G9rROUk';
